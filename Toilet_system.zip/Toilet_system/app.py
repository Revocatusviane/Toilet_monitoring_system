from flask import Flask, render_template, request, send_from_directory, jsonify, redirect, url_for
import os
from werkzeug.utils import secure_filename
import cv2
import numpy as np
from datetime import datetime
import base64
from io import BytesIO
from PIL import Image
from ultralytics import YOLO
import logging
import traceback
import pytz
import requests
import time

app = Flask(__name__)

# Configuration
UPLOAD_FOLDER = '/Users/machd/Desktop/Desktop/Python/Mr_samweli_kileo/Toilet_system/static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}
ESP32_URL = 'http://172.20.10.4:5000'

# Logging setup
try:
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s %(levelname)s: %(message)s',
        handlers=[
            logging.FileHandler('/tmp/toilet_system.log'),
            logging.StreamHandler()
        ]
    )
    print("Logging initialized successfully")
except Exception as e:
    print(f"Failed to initialize logging: {str(e)}")
    raise

# Verify upload folder
if not os.access(UPLOAD_FOLDER, os.W_OK):
    print(f"Upload folder {UPLOAD_FOLDER} is not writable")
    raise PermissionError(f"Cannot write to {UPLOAD_FOLDER}")

# Load YOLO models
try:
    toilet_model_path = '/Users/machd/Desktop/Desktop/Python/Mr_samweli_kileo/Toilet_checker/weights/best.pt'
    if not os.path.exists(toilet_model_path):
        raise FileNotFoundError(f"YOLO model not found at {toilet_model_path}")
    toilet_model = YOLO(toilet_model_path)
    person_model = YOLO('yolov8s.pt')
    print("YOLO models loaded successfully")
except Exception as e:
    print(f"Failed to load YOLO models: {str(e)}")
    raise

# Simulated database
toilet_data = {
    'toilet1': {'status': 'UNDESTROYED TOILET', 'user_image': None, 'pre_use_image': None, 'post_use_image': None,
                'responsible_user': None, 'state': 'awaiting_user', 'capture_method': None,
                'user_time': None, 'pre_use_time': None, 'post_use_time': None, 'fume_status': 'good'},
    'toilet2': {'status': 'UNDESTROYED TOILET', 'user_image': None, 'pre_use_image': None, 'post_use_image': None,
                'responsible_user': None, 'state': 'awaiting_user', 'capture_method': None,
                'user_time': None, 'pre_use_time': None, 'post_use_time': None, 'fume_status': 'good'},
    'toilet3': {'status': 'UNDESTROYED TOILET', 'user_image': None, 'pre_use_image': None, 'post_use_image': None,
                'responsible_user': None, 'state': 'awaiting_user', 'capture_method': None,
                'user_time': None, 'pre_use_time': None, 'post_use_time': None, 'fume_status': 'good'}
}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def analyze_toilet_condition(image_path, retries=1):
    logging.debug(f"Analyzing toilet condition for {image_path}")
    for attempt in range(retries + 1):
        try:
            img = cv2.imread(image_path)
            if img is None:
                raise ValueError(f"Failed to load image: {image_path}")
            img = cv2.resize(img, (640, 640))
            cv2.imwrite(image_path, img)
            results = toilet_model(image_path)
            for result in results:
                if len(result.boxes) > 0:
                    class_id = result.boxes.cls[0].item()
                    class_name = result.names[int(class_id)]
                    logging.debug(f"Toilet condition: {class_name}")
                    return class_name
            logging.debug("Toilet condition: UNDESTROYED TOILET")
            return 'UNDESTROYED TOILET'
        except Exception as e:
            logging.error(f"Attempt {attempt + 1} failed: {str(e)}")
            if attempt == retries:
                raise
            time.sleep(1)

def verify_person(image_path):
    logging.debug(f"Verifying person in {image_path}")
    try:
        img = cv2.imread(image_path)
        if img is None:
            raise ValueError(f"Failed to load image: {image_path}")
        img = cv2.resize(img, (640, 640))
        cv2.imwrite(image_path, img)
        results = person_model(image_path)
        for result in results:
            if len(result.boxes) > 0:
                for box in result.boxes:
                    class_id = box.cls[0].item()
                    if result.names[int(class_id)] == 'person':
                        logging.debug("Person detected")
                        return True
        logging.debug("No person detected")
        return False
    except Exception as e:
        logging.error(f"Person verification failed: {str(e)}")
        raise

def control_hardware(toilet_id, status, fume_status):
    logging.debug(f"Controlling hardware for {toilet_id}: status={status}, fume_status={fume_status}")
    try:
        red_on = status == 'DESTROYED TOILET' or fume_status == 'bad'
        green_on = status == 'UNDESTROYED TOILET' and fume_status == 'good'
        for attempt in range(3):
            try:
                requests.get(f"{ESP32_URL}/control?action=red_led_{'on' if red_on else 'off'}", timeout=2)
                requests.get(f"{ESP32_URL}/control?action=green_led_{'on' if green_on else 'off'}", timeout=2)
                logging.info(f"LEDs updated: Red={'ON' if red_on else 'OFF'}, Green={'ON' if green_on else 'OFF'}")
                return
            except requests.exceptions.RequestException as e:
                logging.warning(f"Attempt {attempt + 1} to control LEDs failed: {e}")
                time.sleep(1)
        logging.error("Failed to control LEDs after 3 attempts")
    except Exception as e:
        logging.error(f"Failed to control hardware: {str(e)}")

def notify_esp32(toilet_id, action):
    logging.debug(f"Notifying ESP32 for {toilet_id}: action={action}")
    for attempt in range(3):
        try:
            response = requests.get(f"{ESP32_URL}/control?action={action}", timeout=2)
            logging.info(f"ESP32 notified: {action}, Response: {response.status_code}, {response.text}")
            return response.status_code == 200
        except requests.exceptions.RequestException as e:
            logging.warning(f"Attempt {attempt + 1} to notify ESP32 failed: {e}")
            time.sleep(1)
    logging.error(f"Failed to notify ESP32 for {action} after 3 attempts")
    return False

@app.route('/')
def index():
    logging.info("Rendering user view")
    return render_template('index.html', toilets=toilet_data)

@app.route('/status')
def status():
    logging.debug("Fetching toilet status")
    return jsonify(toilet_data)

@app.route('/select/<toilet_id>', methods=['POST'])
def select_toilet(toilet_id):
    logging.debug(f"Selecting toilet: {toilet_id}")
    if toilet_id not in toilet_data:
        logging.error(f"Invalid toilet ID: {toilet_id}")
        return jsonify({'error': 'Invalid toilet ID'}), 400
    if toilet_data[toilet_id]['state'] != 'awaiting_user':
        logging.error(f"Toilet {toilet_id} already in use, state: {toilet_data[toilet_id]['state']}")
        return jsonify({'error': 'Toilet is already in use', 'message': 'Toilet in use'}), 400
    toilet_data[toilet_id]['state'] = 'awaiting_user_image'
    logging.info(f"Toilet {toilet_id} selected, state: awaiting_user_image")
    return jsonify({'success': True, 'message': 'Toilet selected'})

@app.route('/capture/<toilet_id>/<image_type>', methods=['GET'])
def capture_image(toilet_id, image_type):
    logging.debug(f"Starting OpenCV capture for {toilet_id}, type: {image_type}")
    if toilet_id not in toilet_data:
        logging.error(f"Invalid toilet ID: {toilet_id}")
        return jsonify({'error': 'Invalid toilet ID'}), 400
    if image_type not in ['user', 'pre_use', 'post_use']:
        logging.error(f"Invalid image type: {image_type}")
        return jsonify({'error': f'Invalid image type: {image_type}'}), 400

    try:
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            logging.error("Failed to open camera")
            return jsonify({'error': 'Failed to open camera', 'message': 'Camera unavailable'}), 500

        ret, frame = cap.read()
        if not ret:
            logging.error("Failed to capture frame")
            cap.release()
            return jsonify({'error': 'Failed to capture frame', 'message': 'Capture failed'}), 500

        capture_time = datetime.now(pytz.timezone('Africa/Nairobi')).strftime('%Y%m%d_%H%M%S')
        filename = secure_filename(f"{toilet_id}_{image_type}_{capture_time}.jpg")
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        cv2.imwrite(file_path, frame)
        logging.debug(f"Captured image saved: {file_path}")

        cap.release()

        return process_captured_image(toilet_id, image_type, filename, file_path, capture_time)

    except Exception as e:
        logging.error(f"Capture failed: {str(e)}\n{traceback.format_exc()}")
        if 'cap' in locals() and cap.isOpened():
            cap.release()
        return jsonify({'error': f'Capture failed: {str(e)}', 'message': 'Capture error'}), 500

def process_captured_image(toilet_id, image_type, filename, file_path, capture_time):
    logging.debug(f"Processing captured image: {file_path}")
    try:
        if image_type == 'user':
            if not verify_person(file_path):
                os.remove(file_path)
                logging.error(f"User image {filename} does not contain a person")
                return jsonify({'error': 'Image does not contain a person', 'message': 'No person detected'}), 400
            toilet_data[toilet_id]['capture_method'] = 'webcam'

        toilet_data[toilet_id][f"{image_type}_image"] = filename
        toilet_data[toilet_id][f"{image_type}_time"] = capture_time

        if image_type == 'user':
            toilet_data[toilet_id]['state'] = 'awaiting_pre_use'
            notify_esp32(toilet_id, "scan_user")
            logging.info(f"User image captured for {toilet_id}, state: awaiting_pre_use")
        elif image_type == 'pre_use':
            try:
                condition = analyze_toilet_condition(file_path)
                toilet_data[toilet_id]['status'] = condition
                if condition == 'DESTROYED TOILET':
                    toilet_data[toilet_id]['responsible_user'] = None
                    notify_esp32(toilet_id, "select_toilet")
                    logging.info(f"Pre-use DESTROYED for {toilet_id}, user not blamed")
                else:
                    notify_esp32(toilet_id, "select_toilet")
                    toilet_data[toilet_id]['state'] = 'awaiting_done'
                    logging.info(f"Pre-use UNDESTROYED for {toilet_id}, servo unlocked")
                control_hardware(toilet_id, condition, toilet_data[toilet_id]['fume_status'])
            except Exception as e:
                os.remove(file_path)
                logging.error(f"Failed to analyze pre-use image: {str(e)}")
                return jsonify({'error': f'Failed to process pre-use image: {str(e)}', 'message': 'Processing error'}), 500
        elif image_type == 'post_use':
            try:
                condition = analyze_toilet_condition(file_path)
                if toilet_data[toilet_id]['status'] == 'UNDESTROYED TOILET' and condition == 'DESTROYED TOILET':
                    toilet_data[toilet_id]['responsible_user'] = toilet_data[toilet_id]['user_image']
                toilet_data[toilet_id]['status'] = condition
                toilet_data[toilet_id]['state'] = 'done'
                notify_esp32(toilet_id, f"post_use={condition}")
                logging.info(f"Post-use image for {toilet_id}, condition: {condition}")
                control_hardware(toilet_id, condition, toilet_data[toilet_id]['fume_status'])
            except Exception as e:
                os.remove(file_path)
                logging.error(f"Failed to analyze post-use image: {str(e)}")
                return jsonify({'error': f'Failed to process post-use image: {str(e)}', 'message': 'Processing error'}), 500

        return jsonify({'success': True, 'message': f'{image_type.replace("_", " ").title()} image processed', 'state': toilet_data[toilet_id]['state']})

    except Exception as e:
        logging.error(f"Processing failed: {str(e)}\n{traceback.format_exc()}")
        if os.path.exists(file_path):
            os.remove(file_path)
        return jsonify({'error': f'Processing failed: {str(e)}', 'message': 'Processing error'}), 500

@app.route('/upload/<toilet_id>', methods=['POST'])
def upload_image(toilet_id):
    logging.debug(f"Starting upload for {toilet_id}, form: {request.form}, files: {request.files}")
    if toilet_id not in toilet_data:
        logging.error(f"Invalid toilet ID: {toilet_id}")
        return jsonify({'error': 'Invalid toilet ID', 'message': 'Invalid toilet'}), 400

    image_type = request.form.get('image_type')
    if image_type not in ['user', 'pre_use', 'post_use']:
        logging.error(f"Invalid image type: {image_type}")
        return jsonify({'error': f'Invalid image type: {image_type}', 'message': 'Invalid image type'}), 400

    expected_states = {
        'user': ['awaiting_user_image'],
        'pre_use': ['awaiting_pre_use'],
        'post_use': ['awaiting_post_use']
    }
    current_state = toilet_data[toilet_id]['state']
    if current_state not in expected_states.get(image_type, []):
        logging.warning(f"State mismatch for {toilet_id}: expected {expected_states[image_type]}, got {current_state}")
        return jsonify({'error': f'Invalid state: expected {expected_states[image_type]}, got {current_state}', 'message': 'State mismatch'}), 400

    capture_method = 'manual'
    capture_time = datetime.now(pytz.timezone('Africa/Nairobi')).strftime('%Y-%m-%d %H:%M:%S')

    if image_type == 'user':
        toilet_data[toilet_id]['capture_method'] = capture_method

    try:
        file_path = None
        filename = None
        if 'file' in request.files and request.files['file'].filename:
            file = request.files['file']
            if not allowed_file(file.filename):
                logging.error(f"Invalid file extension: {file.filename}")
                return jsonify({'error': f'Invalid file type: {file.filename}. Allowed: {ALLOWED_EXTENSIONS}', 'message': 'Invalid file type'}), 400
            filename = secure_filename(f"{toilet_id}_{image_type}_{datetime.now(pytz.timezone('Africa/Nairobi')).strftime('%Y%m%d_%H%M%S')}.jpg")
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)
            logging.debug(f"Saved file upload: {file_path}")
        else:
            logging.error("No image data provided")
            return jsonify({'error': 'No image provided', 'message': 'No image selected'}), 400

        if image_type == 'user':
            try:
                if not verify_person(file_path):
                    os.remove(file_path)
                    logging.error(f"User image {filename} does not contain a person")
                    return jsonify({'error': 'Image does not contain a person', 'message': 'No person detected'}), 400
            except Exception as e:
                os.remove(file_path)
                logging.error(f"Person verification failed: {str(e)}")
                return jsonify({'error': f'Person verification failed: {str(e)}', 'message': 'Verification error'}), 500

        toilet_data[toilet_id][f"{image_type}_image"] = filename
        toilet_data[toilet_id][f"{image_type}_time"] = capture_time

        if image_type == 'user':
            toilet_data[toilet_id]['state'] = 'awaiting_pre_use'
            notify_esp32(toilet_id, "scan_user")
            logging.info(f"User image uploaded for {toilet_id}, state: awaiting_pre_use")
        elif image_type == 'pre_use':
            try:
                condition = analyze_toilet_condition(file_path)
                toilet_data[toilet_id]['status'] = condition
                if condition == 'DESTROYED TOILET':
                    toilet_data[toilet_id]['responsible_user'] = None
                    notify_esp32(toilet_id, "select_toilet")
                    logging.info(f"Pre-use DESTROYED for {toilet_id}, user not blamed")
                else:
                    notify_esp32(toilet_id, "select_toilet")
                    toilet_data[toilet_id]['state'] = 'awaiting_done'
                    logging.info(f"Pre-use UNDESTROYED for {toilet_id}, servo unlocked")
                control_hardware(toilet_id, condition, toilet_data[toilet_id]['fume_status'])
            except Exception as e:
                os.remove(file_path)
                logging.error(f"Failed to analyze pre-use image: {str(e)}")
                return jsonify({'error': f'Failed to process pre-use image: {str(e)}', 'message': 'Processing error'}), 500
        elif image_type == 'post_use':
            try:
                condition = analyze_toilet_condition(file_path)
                if toilet_data[toilet_id]['status'] == 'UNDESTROYED TOILET' and condition == 'DESTROYED TOILET':
                    toilet_data[toilet_id]['responsible_user'] = toilet_data[toilet_id]['user_image']
                toilet_data[toilet_id]['status'] = condition
                toilet_data[toilet_id]['state'] = 'done'
                notify_esp32(toilet_id, f"post_use={condition}")
                logging.info(f"Post-use image for {toilet_id}, condition: {condition}")
                control_hardware(toilet_id, condition, toilet_data[toilet_id]['fume_status'])
            except Exception as e:
                os.remove(file_path)
                logging.error(f"Failed to analyze post-use image: {str(e)}")
                return jsonify({'error': f'Failed to process post-use image: {str(e)}', 'message': 'Processing error'}), 500

        return jsonify({'success': True, 'message': f'{image_type.replace("_", " ").title()} image uploaded', 'state': toilet_data[toilet_id]['state']})

    except Exception as e:
        logging.error(f"Upload failed for {toilet_id}: {str(e)}\n{traceback.format_exc()}")
        if file_path and os.path.exists(file_path):
            os.remove(file_path)
        return jsonify({'error': f'Upload failed: {str(e)}', 'message': 'Upload error'}), 500

@app.route('/done/<toilet_id>', methods=['POST'])
def done(toilet_id):
    logging.debug(f"Starting done action for {toilet_id}")
    if toilet_id not in toilet_data:
        logging.error(f"Invalid toilet ID: {toilet_id}")
        return jsonify({'error': 'Invalid toilet ID', 'message': 'Invalid toilet'}), 400
    if toilet_data[toilet_id]['state'] != 'awaiting_done':
        logging.error(f"Cannot complete: Invalid state {toilet_data[toilet_id]['state']}")
        return jsonify({'error': f'Invalid state: Expected awaiting_done, got {toilet_data[toilet_id]["state"]}', 'message': 'State mismatch'}), 400
    toilet_data[toilet_id]['state'] = 'awaiting_post_use'
    notify_esp32(toilet_id, "done")
    logging.info(f"Toilet {toilet_id} state: awaiting_post_use")
    return jsonify({'success': True, 'message': 'Done processing', 'state': 'awaiting_post_use'})

@app.route('/reset/<toilet_id>', methods=['POST'])
def reset_toilet(toilet_id):
    logging.debug(f"Resetting toilet {toilet_id}")
    if toilet_id not in toilet_data:
        logging.error(f"Invalid toilet ID: {toilet_id}")
        return jsonify({'error': 'Invalid toilet ID', 'message': 'Invalid toilet'}), 400
    toilet_data[toilet_id] = {
        'status': 'UNDESTROYED TOILET', 'user_image': None, 'pre_use_image': None, 'post_use_image': None,
        'responsible_user': None, 'state': 'awaiting_user', 'capture_method': None,
        'user_time': None, 'pre_use_time': None, 'post_use_time': None, 'fume_status': 'good'
    }
    control_hardware(toilet_id, 'UNDESTROYED TOILET', 'good')
    notify_esp32(toilet_id, "select_toilet")
    logging.info(f"Toilet {toilet_id} reset")
    return jsonify({'success': True, 'message': 'Toilet reset', 'state': 'awaiting_user'})

@app.route('/fume/<toilet_id>', methods=['POST'])
def update_fume_status(toilet_id):
    logging.debug(f"Updating fume status for {toilet_id}")
    if toilet_id not in toilet_data:
        logging.error(f"Invalid toilet ID: {toilet_id}")
        return jsonify({'error': 'Invalid toilet ID', 'message': 'Invalid toilet'}), 400
    try:
        data = request.json
        fume_value = data.get('fume_value', 0)
        fume_status = 'bad' if fume_value > 300 else 'good'
        toilet_data[toilet_id]['fume_status'] = fume_status
        logging.info(f"Fume status for {toilet_id}: {fume_status} (value: {fume_value})")
        control_hardware(toilet_id, toilet_data[toilet_id]['status'], fume_status)
        return jsonify({'success': True, 'fume_status': fume_status, 'message': 'Fume status updated'})
    except Exception as e:
        logging.error(f"Failed to update fume status: {str(e)}")
        return jsonify({'error': f'Failed to update fume status: {str(e)}', 'message': 'Fume update error'}), 500

@app.route('/admin')
def admin():
    logging.info("Rendering admin panel")
    return render_template('index.html', toilets=toilet_data, admin=True)

@app.route('/static/uploads/<filename>')
def uploaded_file(filename):
    logging.debug(f"Serving file: {filename}")
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

if __name__ == '__main__':
    try:
        print("\n=== Starting Toilet System ===")
        logging.info("Starting Flask app")
        host = '172.20.10.5'
        port = 5000
        print(f"🚀 Toilet Server running at http://{host}:{port} (Press CTRL+C to quit)\n")
        logging.info(f"Running on http://{host}:{port}")
        app.run(host=host, port=port, debug=True)
    except Exception as e:
        print(f"Server startup failed: {str(e)}")
        logging.error(f"Server startup failed: {str(e)}\n{traceback.format_exc()}")
        raise